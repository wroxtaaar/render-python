import { FormEvent, useEffect, useState } from "react";
type Result={title:string;size:number;seeders:number;leechers:number;magnetUrl:string;infoUrl?:string;guid?:string};
const bytes=(n:number)=>{if(!n)return"0 B";const u=["B","KB","MB","GB","TB"],i=Math.min(4,Math.floor(Math.log(n)/Math.log(1024)));return`${(n/1024**i).toFixed(i?1:0)} ${u[i]}`};
async function request<T>(path:string,init?:RequestInit):Promise<T>{const r=await fetch(path,init),t=await r.text();let d:any;try{d=JSON.parse(t)}catch{d=t}if(!r.ok)throw Error(d?.detail||d?.error||t||r.statusText);return d}
export default function App(){
 const[q,setQ]=useState("The Last of Us"),[results,setResults]=useState<Result[]>([]),[loading,setLoading]=useState(false),[quota,setQuota]=useState<any>(null),[task,setTask]=useState<any>(null),[files,setFiles]=useState<any[]>([]),[error,setError]=useState("");
 const load=async()=>{try{setQuota(await request("/api/seedr/quota"));const f=await request<any>("/api/seedr/files");setFiles(f?.files||[]);const t=await request<any>("/api/seedr/tasks");if(t?.tasks?.length)setTask(t.tasks[0])}catch(e:any){setError(e.message)}};
 const search=async()=>{if(!q.trim())return;setLoading(true);setError("");try{setResults(await request<Result[]>("/api/search?q="+encodeURIComponent(q.trim())))}catch(e:any){setError(e.message)}finally{setLoading(false)}};
 useEffect(()=>{void load()},[]);
 useEffect(()=>{if(!task?.id)return;const timer=window.setInterval(async()=>{try{const x=await request<any>("/api/seedr/tasks/"+encodeURIComponent(task.id));setTask(x.task);if(x.status==="completed"){window.clearInterval(timer);void load()}}catch{}},3000);return()=>window.clearInterval(timer)},[task?.id]);
 const add=async(r:Result)=>{setError("");try{const x=await request<any>("/api/seedr/add",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({magnet:r.magnetUrl,size:r.size})});setTask(x);await load()}catch(e:any){setError(e.message)}};
 return <main className="shell"><header className="header"><div><h1>SeedFlow</h1><p>Lightweight 1337x → Seedr</p></div>{quota&&<div className="quota"><strong>{bytes(quota.remainingSpace)} free</strong><span>{bytes(quota.usedSpace)} / {bytes(quota.maxSpace)}</span></div>}</header>
 <form className="search" onSubmit={(e:FormEvent)=>{e.preventDefault();void search()}}><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search torrents"/><button disabled={loading}>{loading?"Searching…":"Search"}</button></form>
 {error&&<div className="error">{error}</div>}
 {task&&<section className="panel"><div className="row"><strong>{task.title||"Seedr download"}</strong><span>{task.progress??0}%</span></div><div className="progress"><div style={{width:`${task.progress??0}%`}}/></div><small>{task.state||"processing"}</small></section>}
 <section className="results">{results.map(r=><article className="card" key={r.guid||r.magnetUrl}><h2>{r.title}</h2><p className="meta">{bytes(r.size)} · ↑ {r.seeders} · ↓ {r.leechers}</p><div className="actions"><button onClick={()=>void add(r)}>Send to Seedr</button>{r.infoUrl&&<a href={r.infoUrl} target="_blank" rel="noreferrer">Source</a>}</div></article>)}</section>
 <section className="panel"><h2>My Cloud Files</h2>{files.length?<div className="file-list">{files.map((f:any)=><div className="file" key={f.id}><span>{f.name}</span><span>{bytes(f.size)}</span></div>)}</div>:<p className="muted">No files yet.</p>}</section>
 </main>
}
